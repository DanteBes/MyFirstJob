"use scrict";

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.querySelector('.object_btn');
  btn.addEventListener('click', function() {
    alert("привет");
    if (btn) {
      function test2 () {
        alert("Hello"); 
      }
      test2();
    };
    btn.style.backgroundColor = "#FFDA00";
    btn.innerHTML = "КНОПКА";
  });
});